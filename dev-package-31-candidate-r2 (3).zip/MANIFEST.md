# MANIFEST — dev-package-31-candidate-r2.zip  (revision 2d)

**CANDIDATE — NOT ACCEPTED, NOT VERIFIED. Registry 2/31. Stage 4A active. No freeze, no official Test 0.**

Baseline `dev-package-31.zip` (46,788 B, `aff18fd979a05645b74f7eee9d8e4699e89dc0db3fe9a57666981103259ed540`) is preserved unchanged.

12 member files + this manifest. 89511 bytes uncompressed.

Every byte count and hash below was computed **from the member bytes actually placed inside this ZIP**, and
re-verified by extracting the finished archive and recomputing. No count is inherited from an earlier revision.

## Revision history

| Revision | Bytes | SHA-256 | Status |
|---|---|---|---|
| 2b | 48,315 | `1340f8d21ca32537cc3e1a53b82f605e30d05c24226f2ab7f2269167ac95ba6e` | superseded — do not reuse |
| 2c | 48,313 | `5c77bd77621611719da6a770833e91a2df6e1924f80ba9bb8ebcad2bb8358374` | superseded — do not reuse (manifest byte-count defect) |
| **2d (this)** | see external delivery note | see external delivery note | **current** |

## Members

| File | Bytes | SHA-256 |
|---|---|---|
| `CORRECTION-RECORD.md` | 21990 | `5df4e2fe2a4a71379b02b69dd5082723915e1ef106891a17fbb9ae5e2f92cbb2` |
| `countgate-v3-stable.js` | 6719 | `8ea91df53928c4d2bd6a4012be8afc3882ef756ae7c921789a30c772bd508e3f` |
| `dpmc-error.js` | 4284 | `a7c0800caafb643c44b30874c5519e01a70f4f946401ed95852ae5b7224f6470` |
| `pop_contrast.js` | 7262 | `a082d3ceebfa6ca8d449c0a97e824bf337806ecae43fc3d67a5d9c1ce666f82b` |
| `README.md` | 3827 | `f755c230160979d34291a9d620984a3ba7ceaf2ae6a744b39c3ea667659d50d0` |
| `RESULTS.md` | 3960 | `12bec75ac85342333f0ef92df5c43c00fe5cfa01448e93d8960b57d6b6fa893c` |
| `sec93-v2.js` | 8514 | `7921071541da1ab67b55fb8216cbeff4d7b79a1106f5ef51a621e98bbf85ddda` |
| `st0_pgen_engine.js` | 5746 | `8f933ba47ac5526c4b0fe2a434d7e6cbc9055269fd489d20f695e8eb26c3a1b5` |
| `SUPERSEDED-countgate-scaffold.js` | 3200 | `963b834f18ceaabfacad4d6159c007e5d49e4358ac983ec017e1a646da200609` |
| `SUPERSEDED-countgate-v2-unstable.js` | 3060 | `51e649699521ee62d468ae1ee931bce6789173bafe901e05f10da3c5b99b04b7` |
| `SUPERSEDED-sec93-coherence.js` | 8878 | `2648507dea92438cf8eb05003d376bdcf9ad9e1f9033bb78dcf82258c9a2cdb3` |
| `Test0-3-blocker-work-tracker.xlsx` | 12071 | `60afe8925fa857e68568f611d6d7536219468a6452673a978242ac33a8131be1` |

**Member total: 89511 bytes.**

## Archive

This manifest does not contain the hash of the ZIP it is delivered inside. The authoritative archive
hash is stated **externally** in the delivery message.

## Corrections in revision 2d

1. **MANIFEST rebuilt from actual bytes.** Every length and hash recomputed from the member bytes in the archive, not carried forward.
2. **CORRECTION-RECORD byte count corrected.**
3. **Stale duplicates excluded** — no `CORRECTION-RECORD-6.md` or any other superseded duplicate entry.
4. **Post-build verification** — the finished ZIP was extracted and every member re-hashed and re-counted from the extracted contents.

## Verification status (member level, independently reported)

| Check | Result |
|---|---|
| Member integrity | 13/13 PASS |
| Published numerical grid | 20/20 PASS |
| Independent numerical comparison | 8/8 PASS |
| ZIP container verification | **Pending** — must be run against THIS revision's hash, not 2b or 2c |

**Precision note.** The independent numerical comparison used two algebraically different summation methods.
That is strong corroboration, but it is **not** arbitrary-precision verification — no higher-precision
implementation was used.

**No registry item is resolved by this candidate.** §12 forbids resolution by simulated outcome.