// ============================================================================
// SUPERSEDED — DO NOT RUN.  RETAINED FOR AUDIT TRAIL ONLY.
// ============================================================================
// DEFECT: this file computes
//     pIns = 1 - Phi(zHL) * Phi(zLH)      (line ~63)
// which reads Phi(z) as a SUCCESS probability and therefore yields
//     P(at least one cell SUCCEEDS)
// -- a quantity that RISES to 1 with N, the exact inverse of the count gate.
//
// The specification's insufficiency event is
//     P(N_HL < N_min  OR  N_LH < N_min)
// = 1 - P(both cells meet the minimum).
//
// AUTHORITATIVE EVALUATOR: sec93-v2.js (function pIns_correct / pIns_joint).
// Use that file. Do not run or cite this one.
// ============================================================================
// #12 / #27 / #31 JOINT RESOLUTION SWEEP
// Implements Sec 9.3 of Test 0 Specification V1.10 literally, feeds it p_gen(N) from the
// validated disagreement-cell engine, and sweeps (N, m_coh) for pairs satisfying coherence
// for ALL FIVE WORLDS simultaneously.
//
// STATUS: PROVISIONAL-DEV. Validation bounds and pi thresholds have NO approved values (#15),
// so the sweep uses declared provisional bounds. The OUTPUT is a feasibility map, not a
// resolved parameter — Sec 12 forbids resolving a registry item by simulated outcome.
// What this establishes: whether ANY (N, m_coh) pair exists for the provisional bounds.

const PROV = "PROVISIONAL-DEV";
const R = [];

// ---------------- normal CDF ----------------
function erf(y){const s=Math.sign(y);y=Math.abs(y);
  const a1=0.254829592,a2=-0.284496736,a3=1.421413741,a4=-1.453152027,a5=1.061405429,p=0.3275911;
  const t=1/(1+p*y);return s*(1-(((((a5*t+a4)*t)+a3)*t+a2)*t+a1)*t*Math.exp(-y*y));}
const Phi = z => 0.5*(1+erf(z/Math.SQRT2));

// ---------------- bivariate normal CDF (validated in track5b, Delta <= 1.33e-3 vs MC) ----------------
function bvn(a,b,r){ const c=Math.sqrt(1-r*r); const LO=-10, HI=Math.min(a,10);
  if (HI<=LO) return 0; const N=4000, h=(HI-LO)/N;
  const f=x=>Math.exp(-x*x/2)/Math.sqrt(2*Math.PI)*Phi((b-r*x)/c);
  let s=f(LO)+f(HI); for(let i=1;i<N;i++) s+=f(LO+i*h)*(i%2?4:2); return s*h/3; }

// ================= PART 1: the projection identity =================
// (I - (1/4) 1 1^T) 1 = 0
function project(v){ // v in R^4 -> tangent component
  const mean = (v[0]+v[1]+v[2]+v[3])/4;
  return v.map(x => x - mean);
}
{
  const ones=[1,1,1,1];
  const p1=project(ones);
  const norm1=Math.hypot(...p1);
  const a=[0.5,0.3,0.1,0.1];
  const pa=project(a);
  const normA=Math.hypot(...pa);
  // also confirm the projection is idempotent: P(P(a)) = P(a)
  const ppa=project(pa);
  const idem=Math.max(...pa.map((x,i)=>Math.abs(x-ppa[i])));
  R.push({ part:"P1", test:"(I - (1/4)11^T)1 = 0", status: norm1<1e-15?"PASS":"FAIL",
    detail:`||P(1)|| = ${norm1.toExponential(3)} — the all-ones direction is annihilated, so it contributes nothing to the distance metric.`});
  R.push({ part:"P2", test:"projection is idempotent P^2 = P", status: idem<1e-15?"PASS":"FAIL",
    detail:`max |P(P(a)) - P(a)| = ${idem.toExponential(3)} over a=[0.5,0.3,0.1,0.1]`});
  R.push({ part:"P3", test:"tangent norm of a constraint normal is computable", status: normA>0?"PASS":"FAIL",
    detail:`||P(a)||_2 = ${normA.toFixed(6)} for a=[0.5,0.3,0.1,0.1]. This is the denominator in Sec 9.3.`});
}

// ================= PART 2: p_gen(N) from the validated cell engine =================
// Per world: p = (pR, pM, pA, pI). Cell probabilities at theta; scarcity drives pI.
// Worlds (Sec 5.4): W1 pure L_A, W2 present-state, W3 pure L_B, W4 shared confounder, W5 scarcity.
function pgen(world, N, theta, rhoAB, Nmin){
  // disagreement-cell probabilities (standard bivariate normal, corr rhoAB)
  const joint = bvn(theta, theta, rhoAB);
  const Pt = Phi(theta);
  const pHL = Pt - joint, pLH = Pt - joint;
  // P(count failure) = P(N_HL < Nmin or N_LH < Nmin); Poisson-binomial approx via normal
  const mHL = N*pHL, sHL = Math.sqrt(N*pHL*(1-pHL));
  const mLH = N*pLH, sLH = Math.sqrt(N*pLH*(1-pLH));
  const zHL = sHL>0 ? (Nmin-0.5-mHL)/sHL : -Infinity;
  const zLH = sLH>0 ? (Nmin-0.5-mLH)/sLH : -Infinity;
  const pIns = 1 - Phi(zHL)*Phi(zLH);      // approximately independent cells
  // directional split among adequate-count draws, per world design condition (Sec 5.2)
  const design = {
    1:{ dR:0.45, dM:0.05, dA:0.50 },        // R-dominant: D_pop <= -Dmin
    2:{ dR:0.08, dM:0.07, dA:0.85 },        // present-state: AMBIGUOUS modal
    3:{ dR:0.05, dM:0.45, dA:0.50 },        // M-dominant
    4:{ dR:0.10, dM:0.10, dA:0.80 },        // shared confounder: AMBIGUOUS
    5:{ dR:0.45, dM:0.05, dA:0.50 },        // scarcity world (Reading B: R-direction latent)
  }[world];
  const rest = 1 - pIns;
  return [ rest*design.dR, rest*design.dM, rest*design.dA, pIns ];
}

// ================= PART 3: A_w, b_w from provisional validation bounds =================
// Sec 8.2 bounds (PROVISIONAL — #15 has no approved values):
//   pmin_cap    lower on pR  for Worlds 1,3
//   pmin_null   lower on pA  for Worlds 2,4
//   pmin_insuff lower on pI  for World 5
//   pmax_dir    upper on (pR+pM) for Worlds 1,3,5
//   pmax_attrib upper on (pR+pM) for Worlds 2,4
const BOUNDS = { pmin_cap:0.60, pmin_null:0.55, pmin_insuff:0.50, pmax_dir:0.35, pmax_attrib:0.25 };

function constraintsFor(w){
  // rows: [a vector (4), b scalar, label]
  const rows=[];
  const B=BOUNDS;
  if (w===1||w===3){
    rows.push({ a:[-1,0,0,0],  b:-B.pmin_cap,    label:"pR >= pmin_cap" });      // -pR <= -pmin
    rows.push({ a:[1,1,0,0],   b: B.pmax_dir,    label:"pR+pM <= pmax_dir" });
  } else if (w===2||w===4){
    rows.push({ a:[0,0,-1,0],  b:-B.pmin_null,   label:"pA >= pmin_null" });
    rows.push({ a:[1,1,0,0],   b: B.pmax_attrib, label:"pR+pM <= pmax_attrib" });
  } else { // w===5
    rows.push({ a:[0,0,0,-1],  b:-B.pmin_insuff, label:"pI >= pmin_insuff" });
    rows.push({ a:[1,1,0,0],   b: B.pmax_dir,    label:"pR+pM <= pmax_dir" });
  }
  return rows;
}

// Sec 9.3: min over C_w of (b - a.p) / || (I - 1/4 11^T) a ||_2
function coherence(w, p){
  const rows = constraintsFor(w);
  let best = Infinity, worstRow=null;
  for (const r of rows){
    const slack = r.b - (r.a[0]*p[0]+r.a[1]*p[1]+r.a[2]*p[2]+r.a[3]*p[3]);
    const denom = Math.hypot(...project(r.a));
    if (denom <= 0) continue;               // constraint normal entirely in the 1-direction: excluded
    const val = slack/denom;
    if (val < best){ best = val; worstRow = r.label; }
  }
  return { value: best, binding: worstRow };
}

// ================= PART 4: the (N, m_coh) sweep =================
{
  const theta = 0.5, rhoAB = 0.3, Nmin = 10;     // PROVISIONAL
  const Ns = [50,100,200,500,1000,2000,5000,10000,20000,50000];
  const grid = [];
  for (const N of Ns){
    const perWorld = [];
    for (let w=1; w<=5; w++){
      const p = pgen(w, N, theta, rhoAB, Nmin);
      const c = coherence(w, p);
      perWorld.push({ w, p, coh:c.value, binding:c.binding });
    }
    const minCoh = Math.min(...perWorld.map(x=>x.coh));
    grid.push({ N, perWorld, minCoh });
  }
  // viable m_coh: strictly below the min coherence across worlds at that N
  const viable = grid.map(g => ({
    N: g.N,
    maxViable_mcoh: g.minCoh,
    feasible: g.minCoh > 0,
    bindingWorld: g.perWorld.reduce((a,b)=>a.coh<=b.coh?a:b).w,
  }));
  const anyFeasible = viable.filter(v=>v.feasible && v.maxViable_mcoh>0);

  R.push({ part:"P4", test:"coherence computable for all 5 worlds across the N grid",
    status: grid.every(g=>g.perWorld.every(x=>Number.isFinite(x.coh))) ? "PASS":"FAIL",
    detail: `N sampled: ${Ns.join(", ")}; theta=${theta}, rho_AB=${rhoAB}, N_min=${Nmin} [${PROV}]`});
  R.push({ part:"P5", test:"feasible (N, m_coh) pairs exist for the provisional bounds",
    status: anyFeasible.length>0 ? "PASS":"FAIL",
    detail: `${anyFeasible.length}/${Ns.length} N values admit a positive m_coh. Largest headroom: N=${viable.reduce((a,b)=>a.maxViable_mcoh>b.maxViable_mcoh?a:b).N} with m_coh < ${Math.max(...viable.map(v=>v.maxViable_mcoh)).toFixed(4)}.`});
  R.push({ part:"P6", test:"coherence is N-monotone (does it improve with sample size?)",
    status: (()=>{ const v=viable.map(x=>x.maxViable_mcoh); let inc=0; for(let i=1;i<v.length;i++) if(v[i]>v[i-1]) inc++; return inc>=v.length-2?"PASS":"FAIL";})(),
    detail: `min-coherence vs N: ` + viable.map(v=>`${v.N}:${v.maxViable_mcoh.toFixed(4)}`).join(", ") });
  R.push({ part:"P7", test:"binding world identified at each N",
    status: viable.every(v=>v.bindingWorld>=1&&v.bindingWorld<=5) ? "PASS":"FAIL",
    detail: `binding world per N: ` + viable.map(v=>`${v.N}:W${v.bindingWorld}`).join(", ") });

  console.log(JSON.stringify({ sweep: viable, headroom: viable.map(v=>v.maxViable_mcoh) }, null, 2));
}

return { results: R };
