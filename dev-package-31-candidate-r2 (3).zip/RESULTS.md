# RESULTS — Corrective Candidate r2 (#12 / #27 / #31)

**CANDIDATE — NOT ACCEPTED, NOT VERIFIED.** Registry 2/31 · Stage 4A active · no freeze · no Test 0.

> **All numerical results below are CONDITIONAL** on the Sweep C placeholders (a_R = a_M = 0.5,
> sigma_R = sigma_M = 1), theta = 0.5, q = 0.5, N_min = 10, and the stated N grid. They are
> development illustrations, not governing Test 0 criteria. (C4)

---

## Run 3 — Count gate, PUBLISHED grid N = {50, 100, 150, 200}

Evaluator: **countgate-v3-stable.js** (stable lower-tail inclusion–exclusion).
Superseded values in this table were affected by floating-point cancellation.

| World | eff corr | cell P | N=50 | N=100 | N=150 | N=200 |
|---|---|---|---|---|---|---|
| 1 | 0.1111 | 0.232280 | 4.5507e-1 | 3.8664e-4 | 2.6690e-8 | 6.4659e-13 |
| 2 | -0.2000 | 0.282047 | 1.3851e-1 | 4.5405e-6 | 1.1399e-11 | 9.8344e-18 |
| 3 | 0.5111 | 0.164617 | 9.3352e-1 | 4.7948e-2 | 2.0544e-4 | 3.2597e-7 |
| 4 | 0.1111 | 0.232280 | 4.5507e-1 | 3.8664e-4 | 2.6690e-8 | 6.4659e-13 |
| 5 | 0.3333 | 0.195913 | 7.6080e-1 | 6.2468e-3 | 4.1813e-6 | 1.0065e-9 |

**Numerical change record (required entries):**

| Cell | Superseded | Corrected | Note |
|---|---|---|---|
| W1/W4 @ 200 | 8.945066909404886e-13 | **6.4658955764001e-13** | cancellation, ~38% error |
| W2 @ 200 | 1.680877659282487e-13 | **9.83436144614698e-18** | **five orders of magnitude** |
| W2 @ 150 | 1.1456e-11 | **1.1399384308418295e-11** | ~0.5%, mild cancellation |
| W1/W4 @ 150 | 2.6690e-8 | **2.6690123559308652e-8** | prior value confirmed accurate |

Two distinct faults: the near-unit subtraction `1 - P(both succeed)`; and a joint term that
decremented the LH threshold on conditioning, producing values **above 1** (1.3796 for W3 @ N=50).

---

## Run 3b — Estimator comparison, N = {50, 100, 200, 400, 800}

Exact joint vs product-of-binomial-marginals. Error definitions: absolute = I_exact − I_indep;
relative ratio = I_exact / I_indep reported only where I_indep > 0 (else n/a).

| World | max abs error | at N | max relative ratio | at N |
|---|---|---|---|---|
| 1 | 2.5967e-2 | 50 | 1.0605 | 50 |
| 2 | 3.9967e-3 | 50 | 1.0297 | 50 |
| 3 | 2.5225e-2 | 50 | 1.0278 | 50 |
| 4 | 2.5967e-2 | 50 | 1.0605 | 50 |
| 5 | 3.8971e-2 | 50 | 1.0540 | 50 |

**C3 (rewritten).** **W5** has the largest absolute approximation error (0.0389710 at N=50).
**W1/W4** have the largest relative ratio (1.0605 at N=50). The superseded 1.413 and 1.3834 figures
are retained only in the correction history, not as current results.

---

## Run 3c — Extended regression, N = {1600, 3000}

Not part of the published documentation. Regression checks only.

| World | N=1600 | N=3000 |
|---|---|---|
| 1 | 1.6943e-165 | 9.8813e-324 |
| 2 | 4.7467e-211 | 0 (numerical underflow) |
| 3 | 1.7760e-108 | 2.2129e-215 |
| 4 | 1.6943e-165 | 9.8813e-324 |
| 5 | 3.5011e-134 | 2.6611e-264 |

**Underflow labelling.** W2 @ N=3000 returns exactly `0` in double precision. This is **numerical
underflow** — the value lies below the representable range (≈1e-308) — and is NOT a mathematically
exact zero. Values in this table at magnitudes near 1e-300 or smaller carry the same caveat.

---

## §4.1 target labelling (C1)

The threshold `max(D_min, 1.96*se)` corresponds to **target (b)** — zero-exclusion — plus the
observed-effect gate. It is **not** target (a), minimum-effect-interval exclusion.

**C5.** Target (a) is recorded as a **scientific recommendation pending approval**. It is not a
resolved specification decision.

---

## What remains unresolved

| Item | Needs |
|---|---|
| #10 target / #11 procedure | operator decision; both unresolved in the spec |
| #9 D_min | value + rationale |
| #15 validation bounds | five values + justification; vertex-preservation format |
| #12 N, #27 m_coh, #5.5 tuple | contingent on the above |
| #1 rho_AB per world | values |

**Registry: 2 of 31.** No item is closed by this candidate.
