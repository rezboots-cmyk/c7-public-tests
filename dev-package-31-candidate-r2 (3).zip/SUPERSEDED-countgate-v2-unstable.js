// ============================================================================
// SUPERSEDED — DO NOT RUN.  RETAINED FOR AUDIT TRAIL ONLY.
// ============================================================================
//
//  DEFECT: floating-point cancellation in the near-unit subtraction.
//
//  This evaluator computed the exact four-cell multinomial insufficiency as
//
//      I = 1 - P(both cells succeed)
//
//  which subtracts a quantity very close to 1 from 1 whenever the gate is
//  satisfied with high probability. In that regime the leading digits cancel
//  and the result is dominated by double-precision round-off.
//
//  OBSERVED CONSEQUENCES (published cells, now corrected):
//
//      W1/W4 @ N=200   reported 8.945066909404886e-13   corrected 6.4658955764001e-13
//      W2    @ N=200   reported 1.680877659282487e-13   corrected 9.83436144614698e-18
//      W2    @ N=150   reported 1.145600000000000e-11   corrected 1.1399384308418295e-11
//
//  The W2@200 discrepancy is FIVE ORDERS OF MAGNITUDE. The W1/W4@200 value was
//  wrong by ~38%. W2@150 moved by only ~0.5%, consistent with mild cancellation
//  at that cell.
//
//  At N >= 400 the subtraction could also return small NEGATIVE values, which
//  are not probabilities at all.
//
//  ALSO DEFECTIVE (a second, separate fault in this file's lineage): an earlier
//  variant of the joint term used
//      BinCDF(Nmin - 1 - a; N - a, q)
//  decrementing the LH failure threshold when conditioning on the HL count. The
//  threshold does not decrease; the correct term is
//      BinCDF(Nmin - 1; N - a, q)
//  That error produced insufficiency values ABOVE 1 (e.g. 1.3796 for W3 @ N=50).
//
//  STATUS:  SUPERSEDED.  DO NOT RUN.  DO NOT IMPORT.
//
//  ACTIVE EVALUATOR: countgate-v3-stable.js
//  which uses direct lower-tail inclusion-exclusion:
//      I = P(HL fails) + P(LH fails) - P(both fail)
//  with every term a lower-tail probability, so there is no subtraction from 1.
// ============================================================================

// ---- ORIGINAL (DEFECTIVE) IMPLEMENTATION, RETAINED VERBATIM FOR THE RECORD ----
const LF = [0];
for (let i = 1; i <= 6000; i++) LF[i] = LF[i - 1] + Math.log(i);
const lbin = (n, k, p) => LF[n] - LF[k] - LF[n - k] + k * Math.log(p) + (n - k) * Math.log(1 - p);

function binCdfLess(n, p, m) {
  let s = 0;
  for (let k = 0; k < m && k <= n; k++) { const t = Math.exp(lbin(n, k, p)); if (t > 0) s += t; }
  return s;
}

// DEFECTIVE: near-unit subtraction.  Retained for the audit trail only.
function exactIns_UNSTABLE(N, pHL, pLH, Nmin) {
  let good = 0;
  const q = pLH / (1 - pHL);
  for (let a = Nmin; a <= N; a++) {
    const pa = Math.exp(lbin(N, a, pHL));
    if (pa < 1e-300) continue;
    good += pa * (1 - binCdfLess(N - a, q, Nmin));
  }
  return 1 - good;               // <-- cancellation here
}

// DO NOT CALL THESE.  Exported only so a reviewer can confirm the defect.
if (typeof module !== "undefined") {
  module.exports = { exactIns_UNSTABLE, binCdfLess, STATUS: "SUPERSEDED_DO_NOT_RUN" };
}
