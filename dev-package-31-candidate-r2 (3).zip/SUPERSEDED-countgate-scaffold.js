// ============================================================================
// SUPERSEDED — count-gate scaffold sweep. RETAINED FOR AUDIT TRAIL ONLY.
// ============================================================================
// DO NOT USE FOR N SELECTION.
//
// This script computed the exact four-cell multinomial count gate on quadrant
// probabilities taken from a REDUCED model that the specification does not define:
//
//     M = L_B ,  R = L_A ,  Corr(L_A, L_B) = rho_AB ,  diagnostics unstandardised
//
// The specification (V1.10 §2, Diagnostics) instead defines:
//
//     M_cont = L_B + a_M*C + e_M
//     R_cont = L_A + a_R*C + e_R
//     Cov(M,R) = rho_AB + a_M*a_R
//     Corr(M,R) = (rho_AB + a_M*a_R) / sqrt((1+a_M^2+sigma_M^2)(1+a_R^2+sigma_R^2))
//
// The missing confounder loading and the unstandardised diagnostics together made
// the quadrant probabilities wrong, and therefore made the reported minimum N wrong
// by a factor of roughly 2.3-2.4x (too conservative).
//
// Reported values, now SUPERSEDED:
//     P(INS) <= 0.1   -> N = 215   (integer search, reproduced by this file)
//     P(INS) <= 0.05  -> N = 234
//     P(INS) <= 0.01  -> N = 273
//     P(INS) <= 0.001 -> N = 324
//
// The separate set 245 / 266 / 311 / 369 is HISTORICAL, SUPERSEDED, and of
// UNVERIFIED GENERATING METHOD. This file does not produce it. Its origin is not
// held in this package and no search method is attributed to it.
//
// Corrected values (specification cells) are in countgate-v2.js:
//     N = 92 / 100 / 116 / 137
//
// See CORRECTION-RECORD.md for the full derivation and the audit trail.
// ============================================================================

// ---- reduced-model cell probability (WRONG for the specification) ----
// P(M high, R low) for standardised bivariate normal with correlation = rho
const antiDiagScaffold = rho => 0.25 - Math.asin(rho) / (2 * Math.PI);

// ---- exact four-cell multinomial count gate ----
const lfS = [0]; for (let i = 1; i <= 8000; i++) lfS[i] = lfS[i - 1] + Math.log(i);
const lbinS = (n, k, p) => lfS[n] - lfS[k] - lfS[n - k] + k * Math.log(p) + (n - k) * Math.log(1 - p);
function binCdfLessS(n, p, m) { let s = 0; for (let k = 0; k < m && k <= n; k++) { const t = Math.exp(lbinS(n, k, p)); if (t > 0) s += t; } return s; }
function exactInsScaffold(N, p, Nmin) {
  let good = 0; const q = p / (1 - p);
  for (let a = Nmin; a <= N; a++) { const pa = Math.exp(lbinS(N, a, p)); if (pa < 1e-300) continue; good += pa * (1 - binCdfLessS(N - a, q, Nmin)); }
  return Math.max(0, 1 - good);
}

// ---- the worlds as the (wrong) scaffold had them ----
const scaffoldWorlds = [
  { w: 1, rho: 0.0 }, { w: 2, rho: -0.7 }, { w: 3, rho: 0.9 },
  { w: 4, rho: 0.0 }, { w: 5, rho: 0.5 },
];
const NminS = 10;
const out = { status: "SUPERSEDED", cells: [], sweep: [] };
for (const { w, rho } of scaffoldWorlds) out.cells.push({ w, rho, P_HL_scaffold: +antiDiagScaffold(rho).toFixed(6) });
for (const N of [50, 100, 200, 300, 500]) {
  const row = { N };
  for (const { w, rho } of scaffoldWorlds) row["W" + w] = +exactInsScaffold(N, antiDiagScaffold(rho), NminS).toExponential(4);
  out.sweep.push(row);
}
return out;
