// ============================================================================
// countgate-v3-stable.js  --  ACTIVE count-gate evaluator for candidate r2
// ============================================================================
// Sole active evaluator. No other script in this package imports or calls the
// superseded implementation (SUPERSEDED-countgate-v2-unstable.js).
//
// Provenance: code lines are identical to the tested implementation built as
// 'countgate-v4-fixed.js'. Only this header differs.
// ============================================================================
// Corrections applied per the isolation finding:
//  (a) joint term:  BinCDF(Nmin-1-a; N-a, q)  ->  BinCDF(Nmin-1; N-a, q)
//      The LH failure threshold does NOT decrease when conditioning on the HL count.
//  (b) T1 code path: pHL = 0 with Nmin > 0 must give exact insufficiency = 1.
//
// Form: I_exact = P(HL fails) + P(LH fails) - P(both fail), all as lower tails.
// ============================================================================
const MAXN = 6000;
const LF = new Float64Array(MAXN + 1);
for (let i = 1; i <= MAXN; i++) LF[i] = LF[i - 1] + Math.log(i);
const lbin = (n, k, p) => LF[n] - LF[k] - LF[n - k] + k * Math.log(p) + (n - k) * Math.log(1 - p);

function binCdfLE(m, n, p) {
  if (m < 0) return 0;
  if (m >= n) return 1;
  if (p <= 0) return 1;      // no successes possible => X = 0 <= m
  if (p >= 1) return m >= 0 ? 0 : 1;
  let s = 0;
  for (let k = 0; k <= m; k++) { const t = Math.exp(lbin(n, k, p)); if (t > 0) s += t; }
  return Math.min(1, s);
}

function exactIns(N, pHL, pLH, Nmin) {
  // degenerate: if either cell has zero probability, that cell surely fails
  if (pHL <= 0 || pLH <= 0) return { ins: 1, fHL: pHL <= 0 ? 1 : 0, fLH: pLH <= 0 ? 1 : 0, joint: 0 };
  const fHL = binCdfLE(Nmin - 1, N, pHL);
  const fLH = binCdfLE(Nmin - 1, N, pLH);
  const q = pLH / (1 - pHL);
  let joint = 0;
  for (let a = 0; a < Nmin && a <= N; a++) {
    const pa = Math.exp(lbin(N, a, pHL));
    if (pa < 1e-300) continue;
    joint += pa * binCdfLE(Nmin - 1, N - a, q);   // (a) threshold NOT decremented
  }
  let ins = fHL + fLH - joint;
  // clamp only fp noise at the boundaries, and say so
  if (ins < 0 && ins > -1e-12) ins = 0;
  if (ins > 1 && ins < 1 + 1e-12) ins = 1;
  return { ins, fHL, fLH, joint };
}

function indepIns(N, pHL, pLH, Nmin) {
  if (pHL <= 0 || pLH <= 0) return { ins: 1, fHL: pHL <= 0 ? 1 : 0, fLH: pLH <= 0 ? 1 : 0 };
  const fHL = binCdfLE(Nmin - 1, N, pHL);
  const fLH = binCdfLE(Nmin - 1, N, pLH);
  return { ins: fHL + fLH - fHL * fLH, fHL, fLH };
}

// ---------------- six self-tests ----------------
const T = [];
const chk = (name, pass, detail) => { T.push({ test: name, pass, detail }); return pass; };

// T1: pHL = 0, Nmin > 0  =>  exact insufficiency = 1
{
  const r = exactIns(200, 0.0, 0.2, 10);
  chk("T1 pHL=0, Nmin>0 => 1", r.ins === 1, `ins=${r.ins}`);
}
// T2: stable vs original 1-minus form agree in the healthy regime (N=50, moderate p)
{
  function oneMinus(N, pHL, pLH, Nmin) {
    let good = 0; const q = pLH / (1 - pHL);
    for (let a = Nmin; a <= N; a++) {
      const pa = Math.exp(lbin(N, a, pHL)); if (pa < 1e-300) continue;
      const rest = N - a;
      let le = 0; for (let k = 0; k <= Nmin - 1 && k <= rest; k++) { const t = Math.exp(lbin(rest, k, q)); if (t > 0) le += t; }
      good += pa * (1 - le);
    }
    return 1 - good;
  }
  const p = 0.23227952719876999, N = 50;
  const a = exactIns(N, p, p, 10).ins, b = oneMinus(N, p, p, 10);
  chk("T2 stable == 1-minus at N=50", Math.abs(a - b) < 1e-12, `stable=${a} oneMinus=${b} d=${Math.abs(a-b).toExponential(2)}`);
}
// T3: nonnegativity at W1@200 and W2@200
{
  const w1 = exactIns(200, 0.23227952719876999, 0.23227952719876999, 10).ins;
  const w2 = exactIns(200, 0.28204710842448744, 0.28204710842448744, 10).ins;
  chk("T3a W1@200 >= 0", w1 >= 0, `W1@200=${w1}`);
  chk("T3b W2@200 >= 0", w2 >= 0, `W2@200=${w2}`);
}
// T4: 0 <= I <= 1 across the whole grid
{
  let ok = true, hi = 0, lo = 1, at = null;
  const ps = [0.1646170314663114, 0.19591327601530364, 0.23227952719876999, 0.28204710842448744];
  for (const p of ps) for (const N of [50, 100, 200, 400, 800, 1600]) {
    const v = exactIns(N, p, p, 10).ins;
    if (v < 0 || v > 1) { ok = false; at = { p, N, v }; }
    hi = Math.max(hi, v); lo = Math.min(lo, v);
  }
  chk("T4 0 <= I <= 1 across grid", ok, `min=${lo} max=${hi}${at ? " violation=" + JSON.stringify(at) : ""}`);
}
// T5: monotone non-increasing in N
{
  let ok = true, prev = Infinity, bad = null;
  for (const N of [50, 100, 200, 400, 800, 1600, 3000]) {
    const v = exactIns(N, 0.23227952719876999, 0.23227952719876999, 10).ins;
    if (v > prev + 1e-15) { ok = false; bad = { N, v, prev }; }
    prev = v;
  }
  chk("T5 monotone non-increasing in N", ok, bad ? JSON.stringify(bad) : "ok");
}
// T6: -> 0 at large N, nonnegative
{
  const v = exactIns(3000, 0.23227952719876999, 0.23227952719876999, 10).ins;
  chk("T6 ~0 at N=3000, nonneg", v >= 0 && v < 1e-15, `v=${v}`);
}

// ---------------- key values + full grid ----------------
const key = {
  W3_at_50: exactIns(50, 0.1646170314663114, 0.1646170314663114, 10).ins,
  W1_at_200: exactIns(200, 0.23227952719876999, 0.23227952719876999, 10).ins,
  W2_at_200: exactIns(200, 0.28204710842448744, 0.28204710842448744, 10).ins,
};
const W = [{ w: 1, rho: 0.0 }, { w: 2, rho: -0.7 }, { w: 3, rho: 0.9 }, { w: 4, rho: 0.0 }, { w: 5, rho: 0.5 }];
const aR = 0.5, aM = 0.5, sd = 1.5;
const antiDiag = c => 0.25 - Math.asin(c) / (2 * Math.PI);
const cells = W.map(({ w, rho }) => ({ w, rho, eff: (rho + aM * aR) / (sd * sd), p: antiDiag((rho + aM * aR) / (sd * sd)) }));
// Regression sweep grid = comparison grid {50,100,200,400,800} + the N=1600 regression point.
// The published documentation grid {50,100,150,200} is separate; see CORRECTION-RECORD §13.
const Ns = [50, 100, 200, 400, 800, 1600];
const grid = cells.map(c => ({
  world: c.w, effCorr: c.eff, cellP: c.p,
  rows: Ns.map(N => {
    const e = exactIns(N, c.p, c.p, 10), i = indepIns(N, c.p, c.p, 10);
    const absErr = e.ins - i.ins, rel = i.ins > 0 ? e.ins / i.ins : null;
    return { N, exact: e.ins, indep: i.ins, absErr, absErrMag: Math.abs(absErr), rel };
  }),
}));
const maxima = grid.map(g => {
  const a = g.rows.reduce((x, y) => y.absErrMag > x.absErrMag ? y : x);
  const cand = g.rows.filter(r => r.rel !== null);
  const r = cand.length ? cand.reduce((x, y) => y.rel > x.rel ? y : x) : null;
  return { world: g.world, maxAbs: a.absErrMag, maxAbsAtN: a.N, maxRel: r ? r.rel : null, maxRelAtN: r ? r.N : null };
});
return { allPass: T.every(t => t.pass), selfTests: T, keyValues: key, grid, maxima };
