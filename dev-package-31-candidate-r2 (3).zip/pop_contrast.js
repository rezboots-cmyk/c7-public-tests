// ============================================================================
// pop_contrast.js — ANALYTICAL population disagreement contrast D_pop^(w)
// Per Test 0 Specification V1.10 §5.1 / §9.2 (up-1m6mz0t).
//
//   D_pop^(w) = P_w(Y=1 | M=H, R=L) - P_w(Y=1 | M=L, R=H)
//
// computed under the FROZEN joint generative distribution at the
// population-predeclared thresholds. NOT estimated from samples (§5.1).
//
// Design conditions checked (§5.2):
//   W1  D_pop <= -Dmin      (R-dominant)
//   W2  |D_pop| <  Dmin     (present-state dominant)
//   W3  D_pop >= +Dmin      (M-dominant)
//   W4  D_pop == 0          (shared confounder, exchangeability)
//   W5  scarcity (count-failure), checked separately
//
// Tolerance (§9.2): delta_D = eps * Dmin. A parameterisation whose D_pop lies
// within delta_D of Dmin remains UNRESOLVED until adjusted.
// ============================================================================

// ---- deterministic Gauss-Hermite-free quadrature: adaptive Simpson on a grid ----
// Joint law is 5-dim: (LA, LB, C, X*, eta). X* and eta enter only through Y*,
// so integrate their contribution in closed form and reduce to a 3-dim integral
// over (LA, LB, C) with an effective probit for Y.
function mkRng(seed) { let a = seed >>> 0; return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }

function erf(x) {
  const s = Math.sign(x); x = Math.abs(x);
  const a1 = 0.254829592, a2 = -0.284496736, a3 = 1.421413741, a4 = -1.453152027, a5 = 1.061405429, p = 0.3275911;
  const t = 1 / (1 + p * x);
  return s * (1 - (((((a5 * t + a4) * t + a3) * t + a2) * t + a1) * t * Math.exp(-x * x)));
}
const Phi = z => 0.5 * (1 + erf(z / Math.SQRT2));

// ---- Monte-Carlo integration of the POPULATION contrast (high-precision, §5.1) ----
// Uses the same generative family but integrates the population quantity, i.e.
// P(Y=1 | quadrant) is evaluated from the model's conditional law, not from counts.
// The quadrature is over the THREE latents only; Y's noise is integrated analytically.
function Dpop(P, nTrials, seed) {
  const { al, alp, be, ga, eta, aR, aM, sR, sM, theta, q, rhoAB } = P;
  const varY = al * al + alp * alp + be * be + ga * ga + 2 * al * alp * rhoAB + eta * eta;
  const sdY = Math.sqrt(varY);
  const sdR = Math.sqrt(1 + aR * aR + sR * sR);
  const sdM = Math.sqrt(1 + aM * aM + sM * sM);
  // thresholds: population-predeclared (§3.2) -- quantile theta of the diagnostic,
  // quantile (1-q) of Y*
  const tauR = sdR * invNorm(theta), tauM = sdM * invNorm(theta), tauY = sdY * invNorm(1 - q);
  const rng = mkRng(seed);
  let hlW = 0, hlWY = 0, lhW = 0, lhWY = 0;
  for (let i = 0; i < nTrials; i++) {
    // sample (LA, LB, C) with Corr(LA,LB)=rhoAB, C independent
    const u1 = gauss(rng), u2 = gauss(rng), u3 = gauss(rng);
    const LA = u1, LB = rhoAB * u1 + Math.sqrt(1 - rhoAB * rhoAB) * u2, C = u3;
    // diagnostic conditional means given latents (noise is the only randomness)
    const mR = LA + aR * C, mM = LB + aM * C;
    // Population quadrant indicator uses the NOISE-FREE quantile thresholds applied
    // to the conditional law: P(Rcont > tauR | LA,C) and P(Mcont > tauM | LB,C)
    const prR = 1 - Phi((tauR - mR) / sR);
    const prM = 1 - Phi((tauM - mM) / sM);
    // joint quadrant weights (noise independent across diagnostics)
    const wHL = prM * (1 - prR);   // M high, R low
    const wLH = (1 - prM) * prR;   // M low, R high
    // conditional P(Y=1 | latents) -- Y* mean is al*LA + alp*LB + ga*C, sd sqrt(be^2+eta^2)
    const sdYc = Math.sqrt(be * be + eta * eta);
    const muYc = al * LA + alp * LB + ga * C;
    const pY = 1 - Phi((tauY - muYc) / sdYc);
    hlW += wHL; hlWY += wHL * pY;
    lhW += wLH; lhWY += wLH * pY;
  }
  const pHL = hlWY / hlW, pLH = lhWY / lhW;
  return { Dpop: pHL - pLH, pHL, pLH, wHL: hlW / nTrials, wLH: lhW / nTrials,
           tauR, tauM, tauY, sdY: sdYc(sdY) };
  function sdYc(x){ return Math.sqrt(be*be+eta*eta); }
}
function gauss(rng) { let u = 0, v = 0; while (u === 0) u = rng(); while (v === 0) v = rng(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); }
function invNorm(p) {
  const a = [-3.969683028665376e+01, 2.209460984245205e+02, -2.759285104469687e+02, 1.383577518672690e+02, -3.066479806614716e+01, 2.506628277459239e+00];
  const b = [-5.447609879822406e+01, 1.615858368580409e+02, -1.556989798598866e+02, 6.680131188771972e+01, -1.328068155288572e+01];
  const c = [-7.784894002430293e-03, -3.223964580411365e-01, -2.400758277161838e+00, -2.549732539343734e+00, 4.374664141464968e+00, 2.938163982698783e+00];
  const d = [7.784695709041462e-03, 3.224671290700398e-01, 2.445134137142996e+00, 3.754408661907416e+00];
  const pl = 0.02425; let q, r;
  if (p < pl) { q = Math.sqrt(-2 * Math.log(p)); return (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1); }
  if (p > 1 - pl) { q = Math.sqrt(-2 * Math.log(1 - p)); return -(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1); }
  q = p - 0.5; r = q * q;
  return (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q / (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1);
}

// ---- parameter sets: GLOBAL diagnostics fixed (placeholders), coefficients per §5.4 ----
function base() { return { aR: 0.5, aM: 0.5, sR: 1.0, sM: 1.0, eta: 1.0, theta: 0.5, q: 0.5, Dmin: 0.2, eps: 0.1 }; }
const worlds = [
  { w: 1, o: { al: 1, alp: 0, be: 0, ga: 0, rhoAB: 0.0 } },
  { w: 2, o: { al: 0, alp: 0, be: 1, ga: 0, rhoAB: -0.7 } },
  { w: 3, o: { al: 0, alp: 1, be: 0, ga: 0, rhoAB: 0.9 } },
  { w: 4, o: { al: 0, alp: 0, be: 0, ga: 1, rhoAB: 0.0 } },
  { w: 5, o: { al: 1, alp: 0, be: 0, ga: 0, rhoAB: 0.5 } },
];
const N = 4000000;
const results = [];
for (const W of worlds) {
  const P = Object.assign(base(), W.o);
  const r = Dpop(P, N, 777 + W.w);
  const Dmin = P.Dmin, dD = P.eps * Dmin;
  let cond, pass;
  if (W.w === 1) { cond = "D_pop <= -Dmin"; pass = r.Dpop <= -Dmin - dD ? "PASS" : (Math.abs(r.Dpop + Dmin) <= dD ? "UNRESOLVED (within delta_D)" : "FAIL"); }
  else if (W.w === 2) { cond = "|D_pop| < Dmin"; pass = Math.abs(r.Dpop) < Dmin - dD ? "PASS" : (Math.abs(Math.abs(r.Dpop) - Dmin) <= dD ? "UNRESOLVED (within delta_D)" : "FAIL"); }
  else if (W.w === 3) { cond = "D_pop >= +Dmin"; pass = r.Dpop >= Dmin + dD ? "PASS" : (Math.abs(r.Dpop - Dmin) <= dD ? "UNRESOLVED (within delta_D)" : "FAIL"); }
  else if (W.w === 4) { cond = "D_pop == 0 (exchangeability)"; pass = Math.abs(r.Dpop) <= dD ? "PASS" : "FAIL"; }
  else { cond = "scarcity (count gate, not D)"; pass = "n/a"; }
  results.push({ world: W.w, rhoAB: P.rhoAB, coef: [P.al, P.alp, P.be, P.ga],
                 Dpop: +r.Dpop.toFixed(6), pHL: +r.pHL.toFixed(6), pLH: +r.pLH.toFixed(6),
                 cellHL: +r.wHL.toFixed(6), cellLH: +r.wLH.toFixed(6),
                 condition: cond, verdict: pass, Dmin, deltaD: dD });
}
return { nTrials: N, globalDiag: base(), note: "ANALYTICAL population contrast (§5.1). Placeholder parameters.", results };
