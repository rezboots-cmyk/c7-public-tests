// ============================================================================
// st0_pgen_engine.js — Five-world population apparatus-output law p_gen(N)
// Per Test 0 Specification V1.10 (up-1m6mz0t):
//   §2/§2.1 generative model;  §3.2/§3.3 H-L threshold + quadrants;
//   §4 decision operator with uncertainty target declaration (a);
//   §5.1 Dpop;  §9.1 polytope;  §9.3 coherence margin.
// EVERY unresolved value is an explicit parameter. Nothing is chosen here.
// ============================================================================
function cholesky(A) {
  const n = A.length, L = A.map(r => r.slice());
  for (let i = 0; i < n; i++) for (let j = 0; j <= i; j++) {
    let s = L[i][j];
    for (let k = 0; k < j; k++) s -= L[i][k] * L[j][k];
    if (i === j) L[i][j] = Math.sqrt(Math.max(s, 1e-300)); else L[i][j] = s / L[j][j];
  }
  return L;
}
function mulberry32(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
function gauss(rng) { let u = 0, v = 0; while (u === 0) u = rng(); while (v === 0) v = rng(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); }
function invNorm(p) {
  const a = [-3.969683028665376e+01, 2.209460984245205e+02, -2.759285104469687e+02, 1.383577518672690e+02, -3.066479806614716e+01, 2.506628277459239e+00];
  const b = [-5.447609879822406e+01, 1.615858368580409e+02, -1.556989798598866e+02, 6.680131188771972e+01, -1.328068155288572e+01];
  const c = [-7.784894002430293e-03, -3.223964580411365e-01, -2.400758277161838e+00, -2.549732539343734e+00, 4.374664141464968e+00, 2.938163982698783e+00];
  const d = [7.784695709041462e-03, 3.224671290700398e-01, 2.445134137142996e+00, 3.754408661907416e+00];
  const pl = 0.02425; let q, r;
  if (p < pl) { q = Math.sqrt(-2 * Math.log(p)); return (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1); }
  if (p > 1 - pl) { q = Math.sqrt(-2 * Math.log(1 - p)); return -(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1); }
  q = p - 0.5; r = q * q;
  return (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q / (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1);
}
function simulateWorld(P, N, nRep, seed) {
  const rhoAB = P.rhoAB, al = P.al, alp = P.alp, be = P.be, ga = P.ga;
  const aR = P.aR, aM = P.aM, sR = P.sR, sM = P.sM, eta = P.eta;
  const theta = P.theta, q = P.q;
  const varY = al * al + alp * alp + be * be + ga * ga + 2 * al * alp * rhoAB + eta * eta;
  const sdY = Math.sqrt(varY);
  const sdR = Math.sqrt(1 + aR * aR + sR * sR);
  const sdM = Math.sqrt(1 + aM * aM + sM * sM);
  const tauY = sdY * invNorm(1 - q);
  const tauR = sdR * invNorm(theta);
  const tauM = sdM * invNorm(theta);
  const SL = [[1, rhoAB, 0], [rhoAB, 1, 0], [0, 0, 1]];
  const Ch = cholesky(SL);
  const rng = mulberry32(seed);
  let nR = 0, nM = 0, nA = 0, nI = 0, sumD = 0, nD = 0;
  for (let rep = 0; rep < nRep; rep++) {
    let hlY = 0, hlN = 0, lhY = 0, lhN = 0;
    for (let i = 0; i < N; i++) {
      const g0 = gauss(rng), g1 = gauss(rng), g2 = gauss(rng), Xs = gauss(rng), en = gauss(rng);
      const LA = Ch[0][0] * g0;
      const LB = Ch[1][0] * g0 + Ch[1][1] * g1;
      const Cc = g2;
      const Rcont = LA + aR * Cc + sR * gauss(rng);
      const Mcont = LB + aM * Cc + sM * gauss(rng);
      const Ystar = al * LA + alp * LB + be * Xs + ga * Cc + eta * en;
      const Y = Ystar > tauY ? 1 : 0;
      const Mh = Mcont > tauM ? 1 : 0;
      const Rh = Rcont > tauR ? 1 : 0;
      if (Mh === 1 && Rh === 0) { hlN++; hlY += Y; }
      else if (Mh === 0 && Rh === 1) { lhN++; lhY += Y; }
    }
    if (hlN < P.Nmin || lhN < P.Nmin) { nI++; continue; }
    const pHL = hlY / hlN, pLH = lhY / lhN, D = pHL - pLH;
    sumD += D; nD++;
    if (Math.abs(D) >= P.Dmin) {
      const se = Math.sqrt(pHL * (1 - pHL) / hlN + pLH * (1 - pLH) / lhN);
      const lo = D - P.zCrit * se, hi = D + P.zCrit * se;
      if (lo > P.Dmin || hi < -P.Dmin) { D > 0 ? nM++ : nR++; continue; }
    }
    nA++;
  }
  return { N, pR: nR / nRep, pM: nM / nRep, pA: nA / nRep, pI: nI / nRep, meanD: nD ? sumD / nD : null, nRep };
}
// §9.3 coherence margin against caller-supplied §8.2 bound rows
function coherence(pgen, rows) {
  const proj = a => { const m = a.reduce((s, x) => s + x, 0) / 4; return a.map(x => x - m); };
  let minD = Infinity, argmin = null;
  for (const row of rows) {
    const Pn = proj(row.a);
    const norm = Math.sqrt(Pn.reduce((s, x) => s + x * x, 0));
    if (norm < 1e-12) continue;
    const slack = row.b - row.a.reduce((s, x, i) => s + x * pgen[i], 0);
    const d = slack / norm;
    if (d < minD) { minD = d; argmin = row.label; }
  }
  return { margin: minD, binding: argmin };
}
const P0 = { aR: 0.5, aM: 0.5, sR: 1.0, sM: 1.0, eta: 1.0, theta: 0.5, q: 0.5, Nmin: 10, Dmin: 0.2, zCrit: 1.96 };
const worlds = [
  { w: 1, o: { rhoAB: 0.0, al: 1, alp: 0, be: 0, ga: 0 } },
  { w: 2, o: { rhoAB: -0.7, al: 0, alp: 0, be: 1, ga: 0 } },
  { w: 3, o: { rhoAB: 0.9, al: 0, alp: 1, be: 0, ga: 0 } },
  { w: 4, o: { rhoAB: 0.0, al: 0, alp: 0, be: 0, ga: 1 } },
  { w: 5, o: { rhoAB: 0.5, al: 1, alp: 0, be: 0, ga: 0 } },
];
const Ns = [50, 100, 200, 300, 500], nRep = 400;
const out = { worldResults: [] };
for (const W of worlds) {
  const P = Object.assign({}, P0, W.o);
  const row = { w: W.w, rhoAB: P.rhoAB, coef: [P.al, P.alp, P.be, P.ga], byN: [] };
  for (const N of Ns) row.byN.push(simulateWorld(P, N, nRep, 1000 + W.w * 977 + N));
  out.worldResults.push(row);
}
return out;
