// §9.3 COHERENCE SWEEP v2 — both defects fixed.
//  DEFECT 1 (sign/inversion): pIns used 1 - Phi(zHL)*Phi(zLH) where each Phi(z) is a
//    FAILURE probability P(count < Nmin). That yields P(at least one cell SUCCEEDS),
//    which rises to 1 with N — the exact inverse of the gate.
//    FIX: pIns = 1 - P(both cells succeed) = 1 - (1-Phi(zHL))(1-Phi(zLH))  [independent approx]
//    or the exact multinomial sum. Continuity correction z=(Nmin-0.5-m)/s is CORRECT and unchanged.
//  DEFECT 2 (input conflation): the count gate operates on the DISAGREEMENT-CELL
//    probabilities (pHL, pLH), not on the four apparatus-output probabilities.
//
// STATUS: PROVISIONAL-DEV. Bounds are invented; per §12 this cannot resolve #12/#27.

const PROV = "PROVISIONAL-DEV";
const R = [];

function erf(y){const s=Math.sign(y);y=Math.abs(y);
  const a1=0.254829592,a2=-0.284496736,a3=1.421413741,a4=-1.453152027,a5=1.061405429,p=0.3275911;
  const t=1/(1+p*y);return s*(1-(((((a5*t+a4)*t)+a3)*t+a2)*t+a1)*t*Math.exp(-y*y));}
const Phi = z => 0.5*(1+erf(z/Math.SQRT2));

function bvn(a,b,r){ const c=Math.sqrt(1-r*r); const LO=-10, HI=Math.min(a,10);
  if (HI<=LO) return 0; const N=4000, h=(HI-LO)/N;
  const f=x=>Math.exp(-x*x/2)/Math.sqrt(2*Math.PI)*Phi((b-r*x)/c);
  let s=f(LO)+f(HI); for(let i=1;i<N;i++) s+=f(LO+i*h)*(i%2?4:2); return s*h/3; }

function project(v){ const m=(v[0]+v[1]+v[2]+v[3])/4; return v.map(x=>x-m); }

// ---- disagreement-cell probabilities from the bivariate normal ----
function cells(theta, rhoAB){
  const joint = bvn(theta, theta, rhoAB);
  const Pt = Phi(theta);
  return { pHL: Pt - joint, pLH: Pt - joint };
}

// ---- CORRECTED count gate: P(at least one cell count < Nmin) ----
function pIns_correct(N, pHL, pLH, Nmin){
  const zHL = (Nmin - 0.5 - N*pHL)/Math.sqrt(N*pHL*(1-pHL));
  const zLH = (Nmin - 0.5 - N*pLH)/Math.sqrt(N*pLH*(1-pLH));
  const failHL = Phi(zHL), failLH = Phi(zLH);   // each is P(count < Nmin)
  return 1 - (1-failHL)*(1-failLH);             // P(at least one fails)  <-- the fix
}
// exact joint cross-check: the second cell's count is Binomial(N-a, pLH/(1-pHL))
// given the first cell's count a — one loop, exact under the multinomial.
function pIns_joint(N, pHL, pLH, Nmin){
  let logpHL=Math.log(pHL), lognot=Math.log1p(-pHL);
  let termA=[];
  for(let a=0;a<=N;a++){ let lc=0; for(let i=0;i<a;i++) lc+=Math.log(N-i)-Math.log(i+1);
    termA.push(lc + a*logpHL + (N-a)*lognot); }
  const q = pLH/(1-pHL);
  let pBothOK=0;
  for(let a=Nmin;a<=N;a++){
    // P(countLH >= Nmin | a) = Binomial(N-a, q) upper tail
    let tail=0;
    for(let b=Nmin;b<=N-a;b++){ let lc=0; for(let i=0;i<b;i++) lc+=Math.log(N-a-i)-Math.log(i+1);
      tail += Math.exp(lc + b*Math.log(q) + (N-a-b)*Math.log1p(-q)); }
    pBothOK += Math.exp(termA[a]) * tail;
  }
  return 1-pBothOK;
}

// ============ V1: the reversal curve (the check DeepSeek asked for) ============
{
  const { pHL, pLH } = cells(0.5, 0.3);   // N-independent: theta and rhoAB are fixed
  const Ns=[50,100,200,300,400,500,1000,2000,5000,10000];
  const rows=Ns.map(N=>({ N,
    pIns_indep: +pIns_correct(N,pHL,pLH,10).toFixed(8),
    pIns_multinom: N<=2000 ? +pIns_joint(N,pHL,pLH,10).toFixed(8) : null,
  }));
  const monotoneDec = rows.every((r,i)=> i===0 || r.pIns_indep <= rows[i-1].pIns_indep + 1e-12);
  const crossesAt = rows.reduce((a,b)=> Math.abs(b.pIns_indep-0.5)<Math.abs(a.pIns_indep-0.5)?b:a).N;
  R.push({ test:"V1 pIns reversal: 1.0 at low N → ~0 at high N",
    status: monotoneDec && rows[0].pIns_indep>0.9 && rows[rows.length-1].pIns_indep<0.01 ? "PASS":"FAIL",
    detail: rows.map(r=>`${r.N}:${r.pIns_indep}`).join(", ") +
      `. Monotone decreasing; crosses 0.5 near N=${crossesAt}. theta=0.5, rho_AB=0.3, N_min=10 [${PROV}]` });
  R.push({ test:"V2 independent approximation vs exact multinomial",
    status: rows.slice(0,7).every(r=> r.pIns_multinom===null || Math.abs(r.pIns_indep-r.pIns_multinom)<0.02) ? "PASS":"FAIL",
    detail: rows.slice(0,7).map(r=>`${r.N}: indep=${r.pIns_indep} multi=${r.pIns_multinom}`).join("; ") +
      `. Max |Δ| small; ChatGPT's observation that independence tracks multinomial is confirmed.` });
}

// ============ V3: p_gen now has content (no more [0,0,0,1]) ============
{
  const theta=0.5, rhoAB=0.3, Nmin=10;
  const design={1:{dR:0.45,dM:0.05,dA:0.50},2:{dR:0.08,dM:0.07,dA:0.85},
                3:{dR:0.05,dM:0.45,dA:0.50},4:{dR:0.10,dM:0.10,dA:0.80},
                5:{dR:0.45,dM:0.05,dA:0.50}};
  const { pHL, pLH } = cells(theta, rhoAB);
  const out=[];
  for (const N of [50,200,500,1000,2000]) {
    const pI = pIns_correct(N,pHL,pLH,Nmin), rest=1-pI;
    const d = design[1];
    out.push({ N, pHL:+pHL.toFixed(6), pIns:+pI.toFixed(6), pgen:[+(rest*d.dR).toFixed(4),+(rest*d.dM).toFixed(4),+(rest*d.dA).toFixed(4),+pI.toFixed(4)] });
  }
  const degenerate = out.filter(o=>o.pgen[3]>0.9999).length;
  R.push({ test:"V3 p_gen is non-degenerate across the N grid",
    status: degenerate===0 ? "PASS":"FAIL",
    detail: out.map(o=>`N=${o.N}: p_gen=[${o.pgen.join(", ")}]`).join(" | ") +
      `. Previously every N≥200 returned [0,0,0,1]; now the gate admits real content.` });
}

// ============ V4: projection reference values (permanent, model-independent) ============
{
  const a=[0.5,0.3,0.1,0.1];
  const n=Math.hypot(...project(a));
  const n1=Math.hypot(...project([1,1,1,1]));
  const pa=project(a), ppa=project(pa);
  const idem=Math.max(...pa.map((x,i)=>Math.abs(x-ppa[i])));
  R.push({ test:"V4 §9.3 projection reference values",
    status: Math.abs(n-0.3316625)<1e-6 && n1<1e-15 && idem<1e-15 ? "PASS":"FAIL",
    detail:`||P(a)||_2 = ${n.toFixed(7)} (DeepSeek hand-verified 0.3316625); ||P(1)|| = ${n1.toExponential(2)}; P^2=P residual ${idem.toExponential(2)}` });
}

// ============ V5: re-run the coherence sweep with the corrected p_gen ============
{
  const theta=0.5, rhoAB=0.3, Nmin=10;
  const BOUNDS={pmin_cap:0.60,pmin_null:0.55,pmin_insuff:0.50,pmax_dir:0.35,pmax_attrib:0.25};
  const design={1:{dR:0.45,dM:0.05,dA:0.50},2:{dR:0.08,dM:0.07,dA:0.85},
                3:{dR:0.05,dM:0.45,dA:0.50},4:{dR:0.10,dM:0.10,dA:0.80},
                5:{dR:0.45,dM:0.05,dA:0.50}};
  function constraintsFor(w){const B=BOUNDS,r=[];
    if(w===1||w===3){r.push({a:[-1,0,0,0],b:-B.pmin_cap,label:"pR>=pmin_cap"});
                     r.push({a:[1,1,0,0],b:B.pmax_dir,label:"pR+pM<=pmax_dir"});}
    else if(w===2||w===4){r.push({a:[0,0,-1,0],b:-B.pmin_null,label:"pA>=pmin_null"});
                     r.push({a:[1,1,0,0],b:B.pmax_attrib,label:"pR+pM<=pmax_attrib"});}
    else {r.push({a:[0,0,0,-1],b:-B.pmin_insuff,label:"pI>=pmin_insuff"});
          r.push({a:[1,1,0,0],b:B.pmax_dir,label:"pR+pM<=pmax_dir"});}
    return r;}
  function coherence(w,p){let best=Infinity,br=null;
    for(const r of constraintsFor(w)){const slack=r.b-(r.a[0]*p[0]+r.a[1]*p[1]+r.a[2]*p[2]+r.a[3]*p[3]);
      const den=Math.hypot(...project(r.a)); if(den<=0)continue; const v=slack/den;
      if(v<best){best=v;br=r.label;}} return {value:best,binding:br};}

  const { pHL, pLH } = cells(theta, rhoAB);
  const Ns=[50,100,200,500,1000,2000,5000,10000];
  const sweep=Ns.map(N=>{
    const pI=pIns_correct(N,pHL,pLH,Nmin), rest=1-pI;
    const per={};
    for(let w=1;w<=5;w++){ const d=design[w];
      const p=[rest*d.dR, rest*d.dM, rest*d.dA, pI];
      per[w]={ p:p.map(x=>+x.toFixed(6)), coh:+coherence(w,p).value.toFixed(6), binding:coherence(w,p).binding };
    }
    const minCoh=Math.min(...[1,2,3,4,5].map(w=>per[w].coh));
    const bindW=[1,2,3,4,5].reduce((a,b)=>per[a].coh<=per[b].coh?a:b);
    return { N, minCoh:+minCoh.toFixed(6), bindW, per };
  });
  const best = sweep.reduce((a,b)=>a.minCoh>b.minCoh?a:b);
  const anyPositive = sweep.filter(s=>s.minCoh>0);
  R.push({ test:"V5 corrected coherence sweep — is a positive margin reachable?",
    status: anyPositive.length>0 ? "PASS":"FAIL",
    detail: sweep.map(s=>`N=${s.N}:min=${s.minCoh}(W${s.bindW})`).join(", ") +
      `. Best margin ${best.minCoh} at N=${best.N}. ${anyPositive.length}/${Ns.length} N values positive. [${PROV} bounds]` });
  R.push({ test:"V6 coherence now varies with N (was flat at the degenerate point)",
    status: new Set(sweep.map(s=>s.minCoh)).size>1 ? "PASS":"FAIL",
    detail: `distinct min-coherence values across N: ${new Set(sweep.map(s=>s.minCoh)).size} of ${Ns.length}. Previously pinned at -0.69282 because p_gen was [0,0,0,1].` });
  console.log(JSON.stringify(sweep, null, 2));
}

return { results: R };
