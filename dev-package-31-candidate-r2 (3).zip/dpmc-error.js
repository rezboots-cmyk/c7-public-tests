// dpmc-error.js — Monte Carlo error estimate for D_pop (World 3 and others)
// Independent seeds, batch means -> standard error. This is the estimator the
// correction record said was MISSING. Note: the simulated-vs-closed-form gap in
// the QUADRANT probability (0.164548 vs 0.164617) is NOT an error estimate for D_pop.
function mk(s) { let a = s >>> 0; return () => { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
function gs(r) { let u = 0, v = 0; while (u === 0) u = r(); while (v === 0) v = r(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); }
function erf(x) { const s = Math.sign(x); x = Math.abs(x); const a1 = 0.254829592, a2 = -0.284496736, a3 = 1.421413741, a4 = -1.453152027, a5 = 1.061405429, p = 0.3275911; const t = 1 / (1 + p * x); return s * (1 - (((((a5 * t + a4) * t + a3) * t + a2) * t + a1) * t * Math.exp(-x * x))); }
const Phi = z => 0.5 * (1 + erf(z / Math.SQRT2));
function invN(p) { const a = [-3.969683028665376e1, 2.209460984245205e2, -2.759285104469687e2, 1.38357751867269e2, -3.066479806614716e1, 2.506628277459239]; const b = [-5.447609879822406e1, 1.615858368580409e2, -1.556989798598866e2, 6.680131188771972e1, -1.328068155288572e1]; const c = [-7.784894002430293e-3, -3.223964580411365e-1, -2.400758277161838, -2.549732539343734, 4.374664141464968, 2.938163982698783]; const d = [7.784695709041462e-3, 3.224671290700398e-1, 2.445134137142996, 3.754408661907416]; const pl = 0.02425; let q, r; if (p < pl) { q = Math.sqrt(-2 * Math.log(p)); return (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1); } if (p > 1 - pl) { q = Math.sqrt(-2 * Math.log(1 - p)); return -(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1); } q = p - 0.5; r = q * q; return (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q / (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1); }

function dpopOne(P, n, seed) {
  const { al, alp, be, ga, eta, aR, aM, sR, sM, theta, q, rhoAB } = P;
  const sdR = Math.sqrt(1 + aR * aR + sR * sR), sdM = Math.sqrt(1 + aM * aM + sM * sM);
  const sdYc = Math.sqrt(be * be + eta * eta);
  const sdY = Math.sqrt(al * al + alp * alp + be * be + ga * ga + 2 * al * alp * rhoAB + eta * eta);
  const tauR = sdR * invN(theta), tauM = sdM * invN(theta), tauY = sdY * invN(1 - q);
  const rng = mk(seed);
  let hlW = 0, hlWY = 0, lhW = 0, lhWY = 0;
  for (let i = 0; i < n; i++) {
    const u1 = gs(rng), u2 = gs(rng), u3 = gs(rng);
    const LA = u1, LB = rhoAB * u1 + Math.sqrt(1 - rhoAB * rhoAB) * u2, C = u3;
    const prR = 1 - Phi((tauR - (LA + aR * C)) / sR);
    const prM = 1 - Phi((tauM - (LB + aM * C)) / sM);
    const wHL = prM * (1 - prR), wLH = (1 - prM) * prR;
    const pY = 1 - Phi((tauY - (al * LA + alp * LB + ga * C)) / sdYc);
    hlW += wHL; hlWY += wHL * pY; lhW += wLH; lhWY += wLH * pY;
  }
  return { D: hlWY / hlW - lhWY / lhW, pHL: hlWY / hlW, pLH: lhWY / lhW };
}
const base = { aR: 0.5, aM: 0.5, sR: 1.0, sM: 1.0, eta: 1.0, theta: 0.5, q: 0.5 };
const worlds = [
  { w: 1, o: { al: 1, alp: 0, be: 0, ga: 0, rhoAB: 0.0 } },
  { w: 2, o: { al: 0, alp: 0, be: 1, ga: 0, rhoAB: -0.7 } },
  { w: 3, o: { al: 0, alp: 1, be: 0, ga: 0, rhoAB: 0.9 } },
  { w: 4, o: { al: 0, alp: 0, be: 0, ga: 1, rhoAB: 0.0 } },
  { w: 5, o: { al: 1, alp: 0, be: 0, ga: 0, rhoAB: 0.5 } },
];
const B = 20, nPer = 500000;   // 20 independent batches x 5e5 draws per world
const report = [];
for (const W of worlds) {
  const P = Object.assign({}, base, W.o);
  const ds = [];
  for (let b = 0; b < B; b++) ds.push(dpopOne(P, nPer, 1000003 + W.w * 7919 + b * 104729).D);
  const mean = ds.reduce((s, x) => s + x, 0) / B;
  const varB = ds.reduce((s, x) => s + (x - mean) ** 2, 0) / (B - 1);
  const se = Math.sqrt(varB / B);
  report.push({ world: W.w, Dpop_mean: +mean.toFixed(6), se: +se.toExponential(3), batches: B, draws: B * nPer, ci95: [+(mean - 1.96 * se).toFixed(6), +(mean + 1.96 * se).toFixed(6)] });
}
return { method: "batch means, 20 independent seeds, 5e5 draws each = 1e7 total per world", report };
