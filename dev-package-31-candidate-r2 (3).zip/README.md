# Synthetic Test 0 — Corrective Candidate r2 (#12 / #27 / #31)

**Status: CANDIDATE — NOT ACCEPTED, NOT VERIFIED. Registry 2/31. Stage 4A active.**
**No protocol freeze. No official Test 0 execution. No GitHub commit.**

Candidate r2 corrects a floating-point cancellation defect in the count-gate evaluator.

The previously verified baseline `dev-package-31.zip` (46,788 B,
`aff18fd979a05645b74f7eee9d8e4699e89dc0db3fe9a57666981103259ed540`) is **preserved unchanged**
and remains the accepted package until this candidate passes independent verification.

---

## 1. Evaluator defect corrected

The active evaluator is **`countgate-v3-stable.js`**, byte-identical to the tested implementation,
computing the exact four-cell multinomial insufficiency by direct lower-tail inclusion–exclusion:

    I = P(HL fails) + P(LH fails) - P(both fail)

Every term is a lower-tail probability, so no subtraction from 1 occurs and no cancellation is possible.

The superseded evaluator is retained as **`SUPERSEDED-countgate-v2-unstable.js`** with a
DO-NOT-RUN banner. **No active script in this package imports or calls it.**

## 2. Numerical change record

| Cell | Superseded value | Corrected value | Note |
|---|---|---|---|
| W1/W4 @ 200 | 8.945066909404886e-13 | **6.4658955764001e-13** | cancellation; ~38% error |
| W2 @ 200 | 1.680877659282487e-13 | **9.83436144614698e-18** | **five orders of magnitude** |
| W2 @ 150 | 1.145600000000000e-11 | **1.1399384308418295e-11** | ~0.5%, mild cancellation |
| W1/W4 @ 150 | 2.6690e-8 | **2.6690123559308652e-8** | prior value confirmed accurate |

Two distinct faults caused these:

1. The near-unit subtraction `1 - P(both succeed)`, which cancels whenever the gate is satisfied with
   high probability, and can return small **negative** values at N ≥ 400.
2. An earlier joint term that **decremented the LH failure threshold** when conditioning on the HL
   count (`BinCDF(Nmin-1-a; N-a, q)`), producing values **above 1** — e.g. 1.3796 for W3 @ N=50.
   The correct term is `BinCDF(Nmin-1; N-a, q)`.

## 3. Three separately labelled grids

| Grid | N values | Purpose |
|---|---|---|
| **Published documentation** | 50, 100, 150, 200 | RESULTS.md Run 3, CORRECTION-RECORD §4 |
| **Estimator comparison** | 50, 100, 200, 400, 800 | C3 absolute/relative error analysis |
| **Extended regression** | 1600, 3000 | regression record only |

## 4. Numerical underflow labelling

Values at or near the floating-point underflow limit are labelled **numerical underflow**, NOT
mathematically exact zero. This applies in particular to **W2 @ N=3000**, reported as `0`: the value
lies below the representable range (≈1e-308).

## 5. C1–C5 documentation corrections

- **C1** · `max(D_min, 1.96·se)` labelled **target (b)** (zero-exclusion + observed-effect gate) — not target (a).
- **C2** · The one-sided 2.5% figure scoped to a symmetric zero-contrast null under an assumed two-sided 5% procedure; not the general wrong-direction probability.
- **C3** · **W5** largest *absolute* approximation error (0.0389710 at N=50); **W1/W4** largest *relative* ratio (1.0605 at N=50). Superseded 1.413 and 1.3834 retained only in correction history.
- **C4** · All numerical results labelled conditional on the Sweep C placeholders, N, N_min and assumed procedure.
- **C5** · §4.1 target (a) recorded as a **scientific recommendation pending approval** — never a resolved specification decision.

---

## Status statement

1. **No registry item is resolved by this candidate.** §12 forbids resolution by simulated outcome.
2. **Every unresolved specification value remains a labelled placeholder.**
3. **This candidate is not accepted** — it requires independent numerical and byte-level verification.
4. **Blocker #15 remains open.** Structural feasibility PASS stands.
