# Correction record — count-gate cell probabilities and the superseded N sweep

**Status: DEVELOPMENT CORRECTION. No registry item is resolved. Registry: 2 of 31.**
Recorded 2026-10-09. Base: Test 0 Specification V1.10 (`up-1m6mz0t`).

---

## 0. Correction to this record — the two-sweep history

> **This section corrects an earlier draft of this record, which described three sweeps (A/B/C).
> There are two.** An intermediate draft asserted a "Sweep B" with `M = L_B`, `R = L_A`,
> σ_M = σ_R = 1.5, cell 0.071783 and N = 215 / 234 / 273 / 324. Reconstruction from the script
> source shows that **cell and those N values are Sweep A's own output.** The generating model had
> been inferred from a probability rather than read from the code that produced it — the exact error
> this record is meant to guard against.

**Two sweeps, both reconstructible from executable source:**

| # | Script | Diagnostic equations | Var / Cov (per diagnostic) | Effective corr (W3) | W3 P(HL) | N values | Status |
|---|---|---|---|---|---|---|---|
| **A** | `SUPERSEDED-countgate-scaffold.js` | `M = L_B`, `R = L_A` | `Var = 1`, `Cov = ρ_AB` | 0.9 | 0.071783 | 215 / 234 / 273 / 324 (integer search). See §1 on 245 / 266 / 311 / 369. | **SUPERSEDED** |
| **C** | `countgate-v2.js` | `M = L_B + a_M·C + ε_M`, `R = L_A + a_R·C + ε_R` | `Var = 2.25`, `Cov = ρ_AB + a_M·a_R` | 0.5111 | 0.164617 | 92 / 100 / 116 / 137 | **CURRENT — conditional** |

**Reconstruction of Sweep A.** `antiDiag(0.9) = 0.25 − asin(0.9)/(2π) = 0.071783`; the exact
four-cell multinomial gate on that cell reproduces 215 / 234 / 273 / 324 at integer-search
resolution. The set 245 / 266 / 311 / 369 is **historical, superseded, and of unverified generating
method** — see §1. No relationship to the 215 / 234 / 273 / 324 set is asserted here.

**Sweep A's model is identified** — from its source, not from its reported probability. No sweep in
this package has an unidentified generating model.

---

## 1. What was wrong

An earlier count-gate sweep (Sweep A) reported candidate minimum sample sizes:

| Threshold on P(INSUFFICIENT) | Superseded N (integer search, verified) | Historical N (generating method unverified) |
|---|---|---|
| ≤ 0.1 | 215 | 245 |
| ≤ 0.05 | 234 | 266 |
| ≤ 0.01 | 273 | 311 |
| ≤ 0.001 | 324 | 369 |

Those figures were computed on quadrant (disagreement-cell) probabilities that the
specification's diagnostic model does not produce. The sweep is **superseded**.

---

## 2. Why

The earlier sweep used a reduced model in which the diagnostics were the latents themselves:

- **Superseded model:** `M = L_B`, `R = L_A`, `Corr(L_A, L_B) = ρ_AB`; diagnostics unstandardised
  (σ_M = σ_R = 1).

The specification (§2, Diagnostics) defines the continuous diagnostics with a shared confounder
and independent error terms:

- **Specification model:** `M_cont = L_B + a_M·C + ε_M`, `R_cont = L_A + a_R·C + ε_R`,
  with `C` independent of the latents and `ε ∼ N(0, σ²)` independent of everything.

Two consequences follow, and the earlier sweep omitted both:

**(i) The confounder loading adds positive covariance.**

    Cov(M, R) = ρ_AB + a_M·a_R

**(ii) The diagnostic noise inflates the variances, which deflates the correlation.**

    Corr(M, R) = (ρ_AB + a_M·a_R) / sqrt((1 + a_M² + σ_M²)(1 + a_R² + σ_R²))

**Note on attribution.** The reduction from ρ_AB = 0.9 to an effective 0.5111 is caused by the
confounder term and the noise variances *together*. It must not be attributed to the confounder
alone. At the placeholders below, `a_M·a_R = +0.25` raises the covariance from 0.9 to 1.15, while
the variance product `2.25` divides it back down. Either term alone would give a different answer.

---

## 3. The corrected cell probabilities

The quadrant probability for a standardised bivariate normal with correlation `c` is

    P(M high, R low) = 0.25 − asin(c)/(2π)

Placeholder globals used throughout: `a_R = a_M = 0.5`, `σ_R = σ_M = 1`, `θ = 0.5`, `N_min = 10`.
Hence `sd_R = sd_M = 1.5` and, for World 3, `Corr = (0.9 + 0.25)/2.25 = 0.5111`.

| World | ρ_AB | Cov(M,R) | Effective corr | Superseded P(HL) | **Correct P(HL)** |
|---|---|---|---|---|---|
| 1 | 0.0 | 0.25 | 0.1111 | 0.250000 | **0.232280** |
| 2 | −0.7 | −0.45 | −0.2000 | 0.373408 | **0.282047** |
| 3 | +0.9 | 1.15 | 0.5111 | 0.071783 | **0.164617** |
| 4 | 0.0 | 0.25 | 0.1111 | 0.250000 | **0.232280** |
| 5 | +0.5 | 0.75 | 0.3333 | 0.166667 | **0.195913** |

Two independent errors compounded in the superseded column: the missing confounder loading
**and** the unstandardised diagnostics. Both are corrected above.

---

## 4. Corrected minimum N (count gate only)

Exact four-cell multinomial gate, `P(N_HL < N_min or N_LH < N_min)`, `N_min = 10`.
Smallest N clearing the threshold for **all five worlds**; World 3 binds in every case.
Evaluator: **countgate-v3-stable.js** (stable lower-tail inclusion–exclusion).

| Threshold | Superseded, integer search (Sweep A) | **Corrected (spec cells)** | Ratio |
|---|---|---|---|
| ≤ 0.1 | 215 | **92** | 2.3× |
| ≤ 0.05 | 234 | **100** | 2.3× |
| ≤ 0.01 | 273 | **116** | 2.4× |
| ≤ 0.001 | 324 | **137** | 2.4× |

### Published per-world grid — N = {50, 100, 150, 200}

Recomputed on the **stable** evaluator. Values below supersede the cancelled figures.

| World | eff corr | cell P(HL) | N=50 | N=100 | N=150 | N=200 |
|---|---|---|---|---|---|---|
| 1 | 0.1111 | 0.232280 | 4.5507e-1 | 3.8664e-4 | 2.6690e-8 | 6.4659e-13 |
| 2 | −0.2000 | 0.282047 | 1.3851e-1 | 4.5405e-6 | 1.1399e-11 | 9.8344e-18 |
| 3 | 0.5111 | 0.164617 | 9.3352e-1 | 4.7948e-2 | 2.0544e-4 | 3.2597e-7 |
| 4 | 0.1111 | 0.232280 | 4.5507e-1 | 3.8664e-4 | 2.6690e-8 | 6.4659e-13 |
| 5 | 0.3333 | 0.195913 | 7.6080e-1 | 6.2468e-3 | 4.1813e-6 | 1.0065e-9 |

**Numerical change record (required entries).**

| Cell | Superseded | Corrected | Note |
|---|---|---|---|
| W1/W4 @ 200 | 8.945066909404886e-13 | **6.4658955764001e-13** | cancellation; ~38% error |
| W2 @ 200 | 1.680877659282487e-13 | **9.83436144614698e-18** | **five orders of magnitude** |
| W2 @ 150 | 1.145600000000000e-11 | **1.1399384308418295e-11** | ~0.5%, mild cancellation |
| W1/W4 @ 150 | 2.6690e-8 | **2.6690123559308652e-8** | prior value confirmed accurate |
| **W3 @ 50** | **1.3795570809841013** | **0.9335179779100725** | joint-term fault: LH threshold was decremented on conditioning, producing a value ABOVE 1. Corrected to `BinCDF(Nmin-1; N-a, q)`. |

**Diagnosis.** Two distinct faults: (i) the near-unit subtraction `1 - P(both succeed)`, which
cancels and can return negative values at N ≥ 400; and (ii) an earlier joint term that
**decremented the LH failure threshold** on conditioning (`BinCDF(Nmin-1-a; N-a, q)`), producing
values **above 1** — e.g. 1.3796 for W3 @ N=50. The correct term is `BinCDF(Nmin-1; N-a, q)`.
The active evaluator is `countgate-v3-stable.js`; the superseded file is retained with a
DO-NOT-RUN banner.

**Underflow labelling.** W2 @ N=3000 returns exactly `0` in double precision. This is
**numerical underflow**, not a mathematically exact zero.

**On the historical set 245 / 266 / 311 / 369.** An earlier draft of this record explained those
figures as the same sweep on a coarser grid. **That explanation is withdrawn.** The originating
script for the 245 set is not held in this package, and the available scaffold script does not
generate it. The figures are therefore recorded as **historical, superseded, with generating method
unverified**. No explanation of their search method is offered, and none should be inferred. They
must not be used for N selection, comparison, or as a verification target.


**Direction of the correction.** The corrected cells are larger for Worlds 1–5 as tabulated, so
counts accumulate faster and the required N is roughly 2.3–2.4× **smaller** than the superseded
figures. The superseded sweep erred on the conservative side.

---

## 5. What these N values are NOT

These are **conditional count-gate results**, not approved sample sizes.

- They depend entirely on placeholder parameters.
- They depend on the definition of the count gate (`N_min = 10` here).
- They do not incorporate the §5.2 design conditions, the §5.6 global-N constraint, or the §9.3
  coherence requirement.
- **They cannot repair a population-level discrimination deficit.** See §6.

---

## 6. The World 3 population-contrast failure stands

    D_pop^(3) ≈ +0.0510      versus      D_min = 0.2

World 3 fails its §5.2 design condition (requires `D_pop ≥ +D_min`). This is a **population-level**
property and is independent of sample size. Increasing N cannot repair it; the parameter design
must be addressed separately. The §5.5 coupled tuple
`(ρ_AB^(5), σ_R^(5), σ_M^(5), N, N_min, π_insuff)` exists for this purpose.

---

## 7. Known limitations of the population-contrast computation

1. **Not fully analytical.** Diagnostic noise and σ_η are integrated in closed form; the three
   latents (L_A, L_B, C) are integrated by **Monte Carlo** at 4×10⁶ draws. The script's internal
   note and the earlier README label this "analytical" — **that label is incorrect** and is
   withdrawn here.
2. **Convergence study performed — supersedes the earlier "none" note.**
   `dpmc-error.js` computes batch means over 20 independent seeds × 5×10⁵ draws = 10⁷ draws per
   world. The resulting standard errors are 7×10⁻⁵ to 1.8×10⁻⁴, and the 95% CIs are:

   | World | D_pop | SE | 95% CI |
   |---|---|---|---|
   | 1 | −0.336284 | 1.20e-4 | [−0.336520, −0.336048] |
   | 2 | 0.000000 | <1e-6 | — |
   | 3 | **+0.050989** | 7.32e-5 | [+0.050846, +0.051132] |
   | 4 | −0.000162 | 1.77e-4 | [−0.000509, +0.000185] |
   | 5 | −0.205336 | 1.23e-4 | [−0.205577, −0.205095] |

   **Withdrawn.** An earlier version of this item cited the 4×10⁻⁵ gap between the engine's
   quadrant probability (0.164578) and the closed-form value (0.164617) as the read on the
   integration error. That gap is in the **quadrant probability**, which is a different quantity;
   it is not an error estimate for `D_pop`. The batch-means standard errors above replace it.

   World 3's SE (7.32×10⁻⁵) is three orders of magnitude below its shortfall to D_min (0.149), so
   the §5.2 failure is not an integration artefact.
3. **World 4's exchangeability is assumed, not enforced.** `D_pop ≈ 5.1×10^-5`, inside δ_D = 0.02,
   but only because `a_R = a_M` and `σ_R = σ_M` were set equal by hand. §5.7's sufficient
   conditions should be derived in the engine, not assumed.
4. **The uncertainty procedure is provisional.** `st0_pgen_engine.js` uses a normal-approximation
   interval with z = 1.96. This is **not** the procedure authorised under #11. The four-outcome
   distribution computed with it remains provisional.
5. **The §3.1 transformation rule is unresolved (registry item 6).** The cells in §3 are computed
   for an *identity* transform, which is classification-equivalent to *standardization* (see §8).
   They are **not** valid for a non-monotone candidate (rank-transform, or log-transform applied to
   negative-valued diagnostics). If the frozen transformation is non-monotone, the cells and the
   N values both change.

---

## 8. The §3.1 transformation qualification

`countgate-v2.js` derives cells as `P(HL) = 0.25 − asin(c)/(2π)`, the *standardised*
bivariate-normal form. §3.1 lists the transformation as UNRESOLVED — identity, standardization,
rank-transform, log-transform (registry item 6) — so this was flagged as an unauthorised assumption.

**It is not a substantive assumption for the first two candidates.** §3.2 defines the threshold as
"the analytical quantile θ of `R_cont` **under the world's generative distribution**". Because
standardization is a strictly increasing linear map, both forms partition the same units into the
same H/L groups:

- **Identity:**     classify `R_cont > quantile_θ(R_cont)`
- **Standardized:** classify `(R_cont − μ)/σ > Φ⁻¹(θ)`

A paired Monte Carlo comparison (4×10⁶ shared draws, ρ_AB = +0.9, σ_R = σ_M = 1.5) gives an
**exactly zero** difference in P(HL) and P(LH) at θ = 0.1, 0.5, 0.7 and 0.9 — not merely at θ = 0.5:

| θ | Identity P(HL) | Standardised P(HL) | \|diff\| |
|---|---|---|---|
| 0.1 | 0.067150 | 0.067150 | 0 |
| 0.5 | 0.164548 | 0.164548 | 0 |
| 0.7 | 0.141840 | 0.141840 | 0 |
| 0.9 | 0.066912 | 0.066912 | 0 |

**Consequence.** The cells in §3 and the N values in §4 are invariant to the choice between identity
and standardization. The live qualification concerns the **non-monotone** candidates only —
rank-transform, and log-transform applied to diagnostics that can take negative values.

### 8.1 The equivalence is a theorem, not an empirical result

The paired Monte Carlo comparison above is a confirmation, not an establishment of the property.
The equivalence follows analytically: for any **strictly increasing** transform `g`, quantiles
commute — `g(q_θ(X)) = q_θ(g(X))`. Standardization is strictly increasing, so

    {R_cont > q_θ(R_cont)}  ≡  {(R_cont − μ)/σ > q_θ(std(R_cont))}

is the **same event** at every θ, hence the same classification and the same quadrant probabilities.
An independent analytical check has since confirmed this to 10⁻⁹ at θ = 0.1, 0.5, 0.7, 0.9, and the
closed-form P(HL) at θ = 0.5 (0.164617) against the Monte Carlo value (0.164548) puts the
simulation error at ≈7×10⁻⁵ — an independent corroboration of the §7.1 limitation note.

The simulation in §8 should therefore be read as a numerical check on the implementation, not as the
basis of the claim.

### 8.2 Attribution — what is and is not withdrawn

**Withdrawn (Claude / this workspace).** An earlier statement in this audit chain held that an
identity transform would move the threshold to `1.5·Φ⁻¹(θ)` and shift every cell probability. That
is **incorrect and is withdrawn**: it conflated a rescaling of the coordinate with a change of
threshold. This is the only retraction in this exchange.

**Not withdrawn (the audit).** No external-audit statement is withdrawn, and none should be recorded
as such. The audit's position was **conditional**: cells are transform-invariant *if* §3.2 defines the
threshold as a marginal quantile of the raw diagnostic, and shift *if* the threshold is instead an
absolute-scale value. §3.2's text — "the analytical quantile θ of `R_cont` under the world's
generative distribution" — **resolves that conditional in favour of quantile thresholds.** The
audit's conditional was therefore the correct formulation, and it is the same reasoning that the
§8.1 theorem above restates. It is recorded here as **confirmed by §3.2**, not retracted.

An earlier draft of this §8 asserted that "the audit was wrong too" about a claimed divergence at
θ ≠ 0.5. **That attribution was itself an error and is withdrawn.** No such claim was made by the
audit; the characterisation is removed.

**Requirement before any direct comparison.** The count-gate script and the four-outcome engine must
use the same frozen transformation, thresholds and diagnostic distribution before their outputs are
placed side by side. `countgate-v2.js` uses the standardised-quantile form; `st0_pgen_engine.js` uses
the raw-quantile form. These agree (above), but the agreement must be an asserted and tested
invariant of the frozen package, not an accident of two separately written scripts.

---

## 9. Three-state status of the N results

| Item | Status |
|---|---|
| Earlier scaffold N sweep (215 / 234 / 273 / 324 on scaffold cells) | **Superseded** as a specification-based calculation |
| Revised identity/standardized N sweep (92 / 100 / 116 / 137) | **Conditional development result** — depends on placeholder parameters, the `N_min = 10` gate definition, and unresolved joint design requirements |
| Final specification-compliant N | **Unresolved** |

---

## 10. D_pop error-estimate audit probes

`dpmc-error.js` reports batch-means standard errors for `D_pop`. Two falsifiable properties of
that estimator were probed. Scripts: `scratch/batch-audit.js`, `scratch/scaling-check.js`.

### 11.1 Batch independence — probe passed

**Risk.** `mulberry32` is a 32-bit counter-based generator, and the shipped estimator steps its seed
by 104729 per batch. If successive seeds produce correlated streams, the batch variance — and hence
the standard error — is understated.

**Probe.** World 3, 12 batches x 250,000 draws (3x10^6 per scheme), three seed-stepping schemes:

| Seed scheme | Mean D_pop | SE |
|---|---|---|
| Shipped (step 104729) | 0.051141 | 1.081e-4 |
| Alternate (step 1000003) | 0.050978 | 8.814e-5 |
| Arbitrary fixed seeds | 0.051105 | 1.356e-4 |

SE ratio max/min = **1.54**; mean spread = 1.6x10^-4. The schemes agree within sampling noise.
**No correlation artefact is detected.**

*Qualification.* 12 batches makes the SE estimate itself noisy, so 1.54 is within the scatter
expected at that batch count. The probe is evidence against a gross artefact, not a proof of
independence.

### 11.2 n^-1/2 scaling — consistent, NOT demonstrated

**Risk.** If the per-batch estimator is biased or the batches are not independent, the SE will not
fall as draws increase.

**Probe.** World 3, 16 batches, four batch sizes at successive doublings (three doublings):

| Draws per batch | Mean D_pop | SE | Ratio vs. previous |
|---|---|---|---|
| 25,000 | 0.050834 | 2.733e-4 | - |
| 50,000 | 0.051022 | 2.408e-4 | 1.135 |
| 100,000 | 0.050930 | 1.635e-4 | 1.473 |
| 200,000 | 0.051025 | 1.199e-4 | 1.364 |

Expected ratio per doubling: sqrt(2) = 1.414. Observed: 1.135, 1.473, 1.364.

**Verdict: consistent with n^-1/2, not demonstrated to be.** The SE falls monotonically and the mean
is stable at 0.0509-0.0510 across an eightfold range of batch size, which is the reassuring part.
But the ratios scatter around 1.414 rather than converging on it. With 16 batches the SE carries a
relative uncertainty of roughly 1/sqrt(2*15) = 18%, and the observed ratios vary by about that much.
A proper convergence test needs 50+ batches per size, which exceeds the sandbox CPU budget in one
run. This probe should be repeated before the estimator is treated as fully characterised.

### 11.3 What these probes do and do not cover

| Item | Status |
|---|---|
| Gaussian quadrant arithmetic (closed form) | Independently checked (external audit) |
| Batch-means seed independence | **Probed — no artefact detected** (§11.1) |
| Batch-means n^-1/2 scaling | **Consistent, not demonstrated** (§11.2) |
| Count gate on Sweep C cells | Not yet independently verified |
| Historical 245 / 266 / 311 / 369 | **Unverifiable** — originating script not held |

Neither probe changes the §6 conclusion. World 3's shortfall to D_min is 0.149, three orders of
magnitude above every SE reported here, so the Section 5.2 failure is insensitive to the
estimator's precision.

---

## 11. Audit trail (artefact status)

The superseded scaffold is **retained, not deleted**, and labelled superseded, so the record shows
how the discrepancy was detected and corrected.

| Artefact | Status |
|---|---|
| Original count-gate sweep (scaffold cells) | **SUPERSEDED** — retained for the audit trail |
| `countgate-v3-stable.js` | **Current — sole active count-gate evaluator.** Stable lower-tail inclusion–exclusion. |
| `CORRECTION-RECORD.md`-referenced `countgate-v2.js` | **SUPERSEDED** by `countgate-v3-stable.js` — the former's near-unit subtraction caused the cancellation defect. Retained as `SUPERSEDED-countgate-v2-unstable.js`. |
| `pop_contrast.js` | Current — with the limitations in §7 |
| `st0_pgen_engine.js` | Current — provisional uncertainty procedure |
| `sec93-v2.js` | **Current — authoritative §9.3 margin evaluator.** Needs §8.2 bound values (#15). |
| `sec93-coherence.js` | **SUPERSEDED** by `sec93-v2.js` — inverted count-gate expression. Retained as `SUPERSEDED-sec93-coherence.js`; DO NOT RUN. |


---

## 13. C1–C5 documentation corrections (candidate r2)

**C1 · Threshold labelling.** `max(D_min, 1.96·se)` corresponds to **target (b)** — zero-exclusion —
plus the observed-effect gate. It is **not** target (a), minimum-effect-interval exclusion.

**C2 · One-sided reference scoped.** The one-sided 2.5% wrong-direction figure applies to a
symmetric zero-contrast null under an assumed two-sided 5% procedure. It is **not** the general
wrong-direction probability for directional Worlds 1, 3 and 5.

**C3 · Absolute versus relative (corrected).** **W5** has the largest *absolute* approximation error
(0.0389710 at N=50). **W1/W4** have the largest *relative* ratio (1.0605 at N=50). The superseded
1.413 and 1.3834 figures are retained in correction history only, not as current results.

**C4 · Conditionality.** Every numerical result in this record is conditional on the Sweep C
placeholders (a_R = a_M = 0.5, sigma_R = sigma_M = 1), theta = 0.5, q = 0.5, N_min = 10, and the
stated N grid. They are development illustrations, not governing Test 0 criteria.

**C5 · Target (a) disposition.** §4.1 target (a) — minimum-effect-interval exclusion — is recorded
as a **scientific recommendation PENDING APPROVAL**. It is **not approved** and is **not a resolved
specification decision**. #10 and #11 remain unresolved.

**Governance.** Registry unchanged at **2 of 31** (#10 and #11). Blocker #15 open. Stage 4A active.
No protocol freeze, no official Test 0 execution, no GitHub commit.


**Grid note.** The regression sweep inside the evaluator uses {50, 100, 200, 400, 800, 1600},
which is the *comparison* grid plus the N=1600 regression point. The published documentation grid
is {50, 100, 150, 200} and the estimator-comparison grid is {50, 100, 200, 400, 800}; the maxima in
RESULTS Run 3b are taken over the five-point comparison grid. The two must not be interchanged.
